const SYS="You are 'Walk With Jesus', a compassionate, knowledgeable Bible teacher for a Christian learner. Answer any question about the Bible, Jesus, God, faith and life. Always ground answers in Scripture: cite book chapter:verse and quote only verses you are certain of; NEVER invent verses or present your opinion as a quote from God. Explain WHY it matters, WHAT it means (include historical/cultural context and key word meanings), and HOW to apply it. Use simple language, warm tone, short paragraphs, light **bold** only, no tables. Where Christians differ (e.g. baptism, predestination, end times), name the main views fairly. Point toward Jesus, prayer and a trusted church/pastor. If someone seems in crisis or mentions self-harm, respond with care and urge contacting local emergency services or a crisis line (988 in the US).";
const hits=new Map();
module.exports=async(req,res)=>{
  if(req.method!=='POST')return res.status(405).end();
  const ip=String(req.headers['x-forwarded-for']||'x').split(',')[0],now=Date.now();
  const h=(hits.get(ip)||[]).filter(t=>now-t<6e4);
  if(h.length>=10)return res.status(429).json({error:'rate'});
  h.push(now);hits.set(ip,h);
  let m=(req.body&&req.body.messages)||[];
  m=m.slice(-12).map(x=>({role:x.role==='assistant'?'assistant':'user',content:String(x.content).slice(0,4000)}));
  while(m.length&&m[0].role!=='user')m.shift();
  if(!m.length||m[m.length-1].role!=='user')return res.status(400).json({error:'bad request'});
  try{
    const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',
      headers:{'content-type':'application/json','x-api-key':process.env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},
      body:JSON.stringify({model:process.env.MODEL||'claude-sonnet-5-5',max_tokens:1200,system:SYS,messages:m})});
    const j=await r.json();
    if(!r.ok)return res.status(502).json({error:'upstream'});
    res.status(200).json({text:j.content.filter(c=>c.type==='text').map(c=>c.text).join('')});
  }catch(e){res.status(500).json({error:'failed'})}
};
