# Walk With Jesus: website

Files: index.html (the app), api/chat.js (AI backend), manifest.json + sw.js + icons (installable on phones).

## Put it online (free, about 10 minutes) with Vercel
1. Create a free account at github.com and make a new repository. Upload everything in this folder to it.
2. Create a free account at vercel.com, click "Add New > Project", and import that repository. Leave every setting as it is.
3. Before deploying, open "Environment Variables" and add:
   - ANTHROPIC_API_KEY = your key from console.anthropic.com
   - (optional) MODEL = the Claude model name you want to use
4. Click Deploy. You get a free link like walk-with-jesus.vercel.app. Later you can connect your own domain in Vercel's settings.

## Protect your wallet
Every AI answer costs a little. In console.anthropic.com set a monthly spend limit. The server already caps each visitor at about 10 questions a minute, but that limit resets if the server restarts, so the spend limit is your real safety net.

## Installing on a phone
iPhone: open the link in Safari, tap Share, then "Add to Home Screen". Android: Chrome menu, then "Install app".

## Before you share widely
Add a short privacy policy page. What to say: journals, notes and progress stay on the user's own device, and questions typed to the AI teacher are sent to Anthropic to be answered. Keep your API key only in Vercel's settings and never inside index.html.
